# Cheyan Design System (CDS) — Agent Implementation Brief

## Mission
Create a reusable personal brand design system for iamcheyan.com and related sites: blog, tutorials/documentation, open-source project sites, and tools. The reference screenshot at `reference/iamcheyan-homepage.png` is the primary visual source of truth. If the live website is accessible, inspect its actual CSS, assets, responsive behavior, and dark mode; distinguish observed values from proposed values. Do not modify the production website without explicit approval.

## Visual DNA
- Japanese editorial / independent publication aesthetic, restrained and spacious.
- Light gray canvas, near-black typography, white inline labels, tiny red outlined circles, thin black rectangular borders, asymmetrical editorial layout.
- Bold sans-serif headings; multilingual Japanese, Chinese, and English support.
- Keep a recognizable identity without forcing every site into identical page templates.

## Proposed starter tokens (verify against original)
- canvas: #EAEAEA
- ink: #161616
- paper: #FFFFFF
- accent: #DF3439
- muted: #737373
- Typeface candidates: Inter, Noto Sans JP, Noto Sans SC, JetBrains Mono. Validate language fallback, loading, licensing, and performance.
- Establish semantic light/dark tokens and check WCAG contrast, especially secondary text and red accents.

## Signature component
Section heading consists of a small red outlined circular marker, a bold Japanese section title, and a bold English label on white rectangular backing. Support Chinese/English-only alternatives when appropriate. Make this a reusable accessible component.

## Deliverables
1. `DESIGN.md`: design principles, brand voice, logo/attribution, visual identity, typography, color, spacing, layout, iconography, imagery, motion, dark mode, responsive, accessibility, do/don't examples.
2. `tokens/`: source JSON tokens for color, typography, spacing, borders, radii, shadows, motion, breakpoints; semantic token layer and light/dark modes.
3. `styles/`: generated CSS variables, base styles, utilities and documented integration instructions.
4. `components/`: framework-agnostic specs and usable components for SiteHeader, SectionHeading, InlineLabel, Link, Button, ProjectCard, ArticleCard, SearchField, SiteFooter, ThemeToggle and BrandAttribution. Choose a concrete framework only after inspecting the existing projects or documenting the choice.
5. `examples/`: responsive portfolio, blog article/index, technical documentation and project landing page examples, each visibly part of the same family yet suited to its purpose.
6. `site/` or `storybook/`: browsable documentation with color swatches, type scale, spacing scale, component states, accessibility notes, and side-by-side application examples.
7. `AGENTS.md`: concise AI-agent implementation rules with MUST/SHOULD/MAY, anti-patterns, and exact reference paths.
8. `README.md`: setup, development, build, adoption and versioning instructions.
9. Screenshots of desktop/mobile, light/dark example pages, and visual comparison against the original reference. Include a change log and unresolved decisions.

## Constraints
- Screenshot is the primary reference; proposed colors/fonts are provisional until checked.
- Avoid generic SaaS dashboards, gradients, glassmorphism, excessive shadows, rounded pill cards everywhere, and unrelated accent colors.
- Do not copy the same page layout into every site; preserve blog reading experience, docs navigation, and project CTAs.
- Semantic HTML, keyboard access, visible focus, reduced-motion support, WCAG AA contrast, responsive layouts, CJK font fallback and code blocks.
- Make components themeable and tokens easy to share across repositories; do not force all sites to adopt one JS framework.
- Do not claim visual fidelity without browser screenshots or image comparison.

## Workflow
1. Audit reference image and, if possible, live site source. Document observed vs inferred features.
2. Create a visual inventory and propose tokens with rationale.
3. Build foundations and signature components first.
4. Build four example applications and documentation gallery.
5. Test desktop/mobile, light/dark, keyboard and accessibility, then capture screenshots.
6. Deliver file tree, commands, screenshots, design decisions and adoption guide.

## Acceptance criteria
- The four example sites share a clear identity without having identical layouts.
- A new AI agent can implement a consistent page using only `DESIGN.md`, `AGENTS.md`, and tokens.
- All colors/typography/spacing are token-driven, not duplicated magic values.
- Every component has documented states, variants and accessibility requirements.
- The documentation site can be built and viewed locally.
- Existing production site remains unchanged unless separately approved.
